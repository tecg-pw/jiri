<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePeopleTable extends Migration {

	public function up()
	{
		Schema::create('people', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->softDeletes();
			$table->string('person_type');
			$table->integer('person_id')->unsigned();
			$table->integer('jiri_id')->unsigned();
		});
	}

	public function down()
	{
		Schema::drop('people');
	}
}