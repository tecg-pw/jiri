<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateJiriesTable extends Migration {

	public function up()
	{
		Schema::create('jiries', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->softDeletes();
			$table->string('name', 255);
			$table->datetime('scheduled_on')->nullable();
			$table->boolean('is_active')->default(false);
			$table->integer('user_id')->unsigned();
		});
	}

	public function down()
	{
		Schema::drop('jiries');
	}
}