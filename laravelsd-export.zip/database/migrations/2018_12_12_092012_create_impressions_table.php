<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateImpressionsTable extends Migration {

	public function up()
	{
		Schema::create('impressions', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->softDeletes();
			$table->integer('user_id')->unsigned();
			$table->integer('student_id')->unsigned();
			$table->integer('jiri_id')->unsigned();
			$table->decimal('general_evaluation');
		});
	}

	public function down()
	{
		Schema::drop('impressions');
	}
}