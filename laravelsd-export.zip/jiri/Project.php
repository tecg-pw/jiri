<?php

namespace Jiri;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Project extends Model 
{

    protected $table = 'projects';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('name', 'description');

    public function implementations()
    {
        return $this->hasMany('Implementation');
    }

    public function events()
    {
        return $this->belongsToMany('Jiri')->withPivot('weights');
    }

}