{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('calculated_score', 'Calculated_score:') !!}
			{!! Form::text('calculated_score') !!}
		</li>
		<li>
			{!! Form::label('manual_score', 'Manual_score:') !!}
			{!! Form::text('manual_score') !!}
		</li>
		<li>
			{!! Form::label('student_id', 'Student_id:') !!}
			{!! Form::text('student_id') !!}
		</li>
		<li>
			{!! Form::label('jiri_id', 'Jiri_id:') !!}
			{!! Form::text('jiri_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}