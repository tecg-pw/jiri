{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('project_id', 'Project_id:') !!}
			{!! Form::text('project_id') !!}
		</li>
		<li>
			{!! Form::label('student_id', 'Student_id:') !!}
			{!! Form::text('student_id') !!}
		</li>
		<li>
			{!! Form::label('jiri_id', 'Jiri_id:') !!}
			{!! Form::text('jiri_id') !!}
		</li>
		<li>
			{!! Form::label('url_project', 'Url_project:') !!}
			{!! Form::text('url_project') !!}
		</li>
		<li>
			{!! Form::label('url_repo', 'Url_repo:') !!}
			{!! Form::text('url_repo') !!}
		</li>
		<li>
			{!! Form::label('weight', 'Weight:') !!}
			{!! Form::text('weight') !!}
		</li>
		<li>
			{!! Form::label('mean_score', 'Mean_score:') !!}
			{!! Form::text('mean_score') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}