{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('scheduled_on', 'Scheduled_on:') !!}
			{!! Form::text('scheduled_on') !!}
		</li>
		<li>
			{!! Form::label('is_active', 'Is_active:') !!}
			{!! Form::text('is_active') !!}
		</li>
		<li>
			{!! Form::label('user_id', 'User_id:') !!}
			{!! Form::text('user_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}