{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('person_type', 'Person_type:') !!}
			{!! Form::text('person_type') !!}
		</li>
		<li>
			{!! Form::label('person_id', 'Person_id:') !!}
			{!! Form::text('person_id') !!}
		</li>
		<li>
			{!! Form::label('jiri_id', 'Jiri_id:') !!}
			{!! Form::text('jiri_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}