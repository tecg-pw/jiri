{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('user_id', 'User_id:') !!}
			{!! Form::text('user_id') !!}
		</li>
		<li>
			{!! Form::label('student_id', 'Student_id:') !!}
			{!! Form::text('student_id') !!}
		</li>
		<li>
			{!! Form::label('jiri_id', 'Jiri_id:') !!}
			{!! Form::text('jiri_id') !!}
		</li>
		<li>
			{!! Form::label('general_evaluation', 'General_evaluation:') !!}
			{!! Form::text('general_evaluation') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}